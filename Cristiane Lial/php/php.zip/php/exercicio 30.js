let k = 5;
let j = 10;
for(i= 10; i>0;i--) {
    if (j%2==0 )
    if (k>0)
    

    j--;
    k--;
    console.log (j);

}