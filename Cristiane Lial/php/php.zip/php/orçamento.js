// parcelas
i=350
while(i>=200){
    console.log(i)
  i--
}