// irá digitar a sua idade
// caso a idade seja maior ou igual a 18
//terá como resposta "maior de idade
//caso contrário,"menor de idade"

a=43


if(a>=18){
    console.log('maior de idade')

}
else{a>=18
    console.log('menor de idade')
}