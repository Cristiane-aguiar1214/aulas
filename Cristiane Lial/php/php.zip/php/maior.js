//descobrir o maior entre dois numeros

a=1
b=2


if (a>b){
console.log('O maior numero é: '+ a) 

}
else{
    console.log( 'O maior numero é: '+b)
}