// Ccompletar ate 100 a 
// partir do numero que o usuario digitar

//variavel do usuario
i = 50

while (i >= 100) {
    console.log (i)
    i--
}