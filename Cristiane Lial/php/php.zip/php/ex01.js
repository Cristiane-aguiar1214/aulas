const numero = 1

numero = 2 

numero2 = numero +1

numero2 = numero2 + 3

numero2 += 3

numero2++