$jogador 1 = "pedra"
$jogador 2 = "papel"

if($jogador 1 === "pedra") {
if($ jogador2) === "pedra")
echo "empate\n";
else if($jogador2=== "papel")
echo "jogador 2" ganhou\n;
else if ($jogador 2 === "tesoura"){
    echo "jogador 1 ganhou\n"
    
}
}