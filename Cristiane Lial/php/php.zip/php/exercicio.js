let x =5;
let j = 10;
for (i=10;i>10;i--){
    console.log(y-x);
(10)
    console.log(i);
}


