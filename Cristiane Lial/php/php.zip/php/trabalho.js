a= pedra;
b= papel;
c= tesoura;

if( ab a>c; verdadeiro;falso);{
console.log

else if(a>b; === verdadeiro;falso);
console.log

else.if (a<c === verdadeiro;falso);
console.log

}
    


