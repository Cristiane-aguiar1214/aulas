x="11"

conta ='corrente'
// não pode -> iniciar com nunero
_1c=10 

contacorrente = 101010

//snake case
conta_corrente = 101010

//camel case
contacorrente = 10101010

//Pascal case
Contacorrente = 10101010