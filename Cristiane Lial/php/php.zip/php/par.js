//verificar se um numero é par ou ímpar

numero = 5

numero/2 
//operador que pega o resto -> módulo -> %
resto = numero % 2
//se(pergunta; resposta verdadeira; resposta falsa)
//console.log(o numero é par)}
if(resto== 0){
    console.log("o resto é par")}
else{
console.log('o numero é impar')
}
// em matemática módulo retira o sinal do número
// em comp -> absoluto -> abs ()

