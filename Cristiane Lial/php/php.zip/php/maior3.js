//descobrir o maior entre 3 numeros

a=4
b=2
c=0

if (a>b && a>c){
    console.log('O maior numero é: '+a)

}
else if(b>c){
    console.log( 'O maior numero é: '+b)
}
else {
    console.log ( 'O maior numero é: '+c)
}