// o usuario digitara dois numeros e 
// o programa dará a soma dos dois números

numero1 = 5
numero2 = 7

soma = numero1 + numero2

console.log(soma)