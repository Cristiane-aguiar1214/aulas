// Contar de 0 ate o numero informado 10
// e do numero informado ate 0
// contagem
i= 0
// usuario informou
usuario = 10

    while(i < usuario){
    console.log (i)
    i ++
    }
while(i >= 0){
    console.log (i)
    i--
}


    