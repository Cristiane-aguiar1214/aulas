8 //usuário digitará o valor do seu salário e o
 //programa irá escrever será o desconto de 
 //6% referente ao vale transporte.

 salario = 5605

 desconto = 6/100

 resultado = salario *desconto

 console.log (resultado.tofixed(2))